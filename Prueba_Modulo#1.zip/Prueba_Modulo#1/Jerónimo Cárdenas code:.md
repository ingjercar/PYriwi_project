Jerónimo Cárdenas code:

folllow this steps to use my code rigth, remember read the instructtion rigth

1. you have to write 5 items to start, but you can put more later
1.1 type the name 
1.2 digit the price in numbers
1.3 digit the amount in numbers

2. now you have this:

"Pon el número de la acción que quieras ejecutar.

NOTA: lee muy bien las instrucciones.

¿Qué deseas hacer?

1. Ingresar producto

2. Buscar producto

3. Actualizar producto

4. Eliminar producto
       ---        
5. Consultar valor total de el stock 

6. Listar productos

7. Salir
"
________________

depend in the number that you choose it will show diferent things like the first one 
is the same at the start:
1.1 type the name 
1.2 digit the price in numbers
1.3 digit the amount in numbers

_________________

in the 2 search_item, it will say for example
-"Digita el nombre de el producto a consultar: mesa"
and you put the name

if its find it it show like"EL producto con nombre "mesa" tiene un valor de "4"$ -por unidad y quedan "3" unidades 

but if its not true, prints
-"El producto a buscar ¡NO SE ENCUENTRA!"

__________________

in the 3 update_item the system ask :
-"Ingresa el nombre de el producto que deseas actualizar: mesa"

then it shows "¿Que deseas actualizar de ese producto? (Precio/Cantidad): precio"

if the name of the product was wrong, prints this:
-"El producto a actualizar ¡NO SE ENCUENTRA!"

is you choose a wrong option "(Precio/Cantidad)" it shows:
-"Opcion invalida"

then if all goes rigth the system cotinue
"digite el nuevo precio para el producto: "

if your answer was a number bigger than 0, prints 
"Producto cambiado con Exito"

if not : "Error! tiene que ser un número."

___________________

in the 4 delete_item it say
-"Ingresa el nombre de el producto que deseas eliminar: mesa"

if that go rigth the code says:
-"El producto se a eliminado con ¡ÉXITO!"

if doesn't go rigth says: "El producto digitado ¡NO EXISTE!"

5 it show the total of pesos that your inventory has:
"El valor total en pesos de todo el inventario es de 4000000$" 

___________________

6 inventory_total it shoud print a list like this:

"____INVENTARIO____

Nombre: mesa

Precio: 4$

Cantidad: 3"

____________________

at 7 finish the system.
Fin del sistema
