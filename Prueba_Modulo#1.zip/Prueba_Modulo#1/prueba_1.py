#inventory=[{"name":"perro", "price":1500.0, "amount":4},{"name":"helicoptero", "price":5000000.0, "amount":1},{"name":"cereal", "price":2500.0, "amount":7},{"name":"haitiano", "price":10.0, "amount":29},{"name":"xilofono", "price":600.0, "amount":15}]
inventory = []
print("Bienvenido al sistema")
print("_____________________")
#____________________this function add a new item to the list______________________-
def new_item():
    m = 0 # if something is wrong the function will star again until it get finished
    while m <= 0:
        name = (input("Digita el nombre del nuevo producto: "))
        print(" ")
        try:
            price = float(input("Digita el precio del nuevo producto: "))
            print(" ")
            if price < 0:
                print("Tiene que ser un numero POSITIVO")
                continue
            try:
                amount = int(input("Digita la cantidad disponibre para el nuevo producto: "))
                print(" ")
                if amount < 0:
                    print("Tiene que ser un numero POSITIVO")
                    continue
                inventory.append({"name":name,"price":price,"amount":amount})
                print("Nuevo producto agregado con ÉXITO!!")
                m = m + 1
            except ValueError:
                print("Error! tiene que ser un número.")# I use the 'try' and 'except error' to validate
                continue
        except ValueError:
            print("Error! tiene que ser un número.")
            continue
#____________________________This function search in all the inventory for the indicated item___________________________
def search_item():
    item_name=str(input("Digita el nombre de el producto a consultar: "))
    print(" ")
    v = 0# This is a kind of counter, it seemed more efficient and simple so that when it doesn't find the name in the list go out
    for item in inventory:
        if item["name"] == item_name:
            print(f"EL producto con nombre {item["name"]} tiene un valor de {item["price"]}$ por unidad y quedan {item["amount"]} unidades.")
        elif v >= len(inventory)-1:
            print("El producto a buscar ¡NO SE ENCUENTRA!")
        else:
            v=v+1
##_________________________this one update any item, well if you write it______________________________________
def update_item():
    item_name = str(input("Ingresa el nombre de el producto que deseas actualizar: "))
    g=0
    update = input("¿Que deseas actualizar de ese producto? (Precio/Cantidad): ").capitalize()
    for item in inventory:
        if item["name"] == item_name:
                if update == "Cantidad":
                    print(" ")
                    try:
                        amount = int(input("digite la cantidad del nuevo producto: "))
                        item.update({"amount":amount})
                    except ValueError:# I use the try and except error to validate
                        print("Error! tiene que ser un número.")
                elif update == "Precio":
                    print(" ")
                    try:
                        price = float(input("digite el nuevo precio para el producto: "))
                        if price < 0:
                            print("Tiene que ser un numero POSITIVO")
                            continue
                        item.update({"price":price})
                        print("Producto cambiado con Exito")
                    except ValueError:# here too
                        print("Error! tiene que ser un número.")
                else:
                    print(" ")
                    print("Opcion invalida")  
        elif g >= len(inventory)-1:
            print("No se encuentra ese producto")
        else: 
            g= g + 1
            continue
#_________________________here i use the same system as search, but instead of show it, i remove it from the list___________________-
def delete_item():
    item_name = str(input("Ingresa el nombre de el producto que deseas eliminar: "))
    print(" ")
    v = 0
    for item in inventory:
        if item["name"] == item_name:
            inventory.remove(item)
            print("El producto se ha eliminado con ¡ÉXITO!")
        elif v >= len(inventory)-1:# This is the counter again, I found it more efficient and simple so when it doesn't find the name in the list go back to the menu
            print("El producto digitado ¡NO EXISTE!")
            print("El producto se ha eliminado con ¡ÉXITO!")
        else:
            v=v+1# This is added every time the name is not found until the number of products is exceeded.
#_________________________lambda to find the value in pesos for all the inventory_________________________
def inventory_total():
        operation = lambda inventory: sum(item["price"]*item["amount"]for item in inventory)# this is the lambda use to sum the total inventory
        total = operation(inventory)
        print(f"El valor total en pesos de todo el inventario es de {total:.2f}$")
#_________________________here i show the list quite better, improving the desing_________________________
def list_inventory():
    print("____INVENTARIO____")
    for item in inventory:# counter that goes through the list and divides it and prints the list in an organized way
        print(f"""---
Nombre: {item["name"]}

Precio: {item["price"]}$

Cantidad: {item["amount"]}
----""")
#_________________________this is the main screen_________________________

answer="""
Pon el número de la acción que quieras ejecutar.

NOTA: lee muy bien las instrucciones.

¿Qué deseas hacer?

1. Ingresar producto

2. Buscar producto

3. Actualizar producto

4. Eliminar producto
       ---        
5. Consultar valor total de el stock 

6. Listar productos

7. Salir

 """
#so you have two options here, if you are lazy you descomment the first line i have 5 item ready for be proved or start like this and make the 5 items.
print("El inventario está vacio, para continuar ingresa 5 productos") 
while len(inventory) < 5:
    new_item()
    print("-")
    
while True:
    print("       ---        ")
    option = input(answer)
    print(" ")
    if option == "1":
        new_item()
    elif option == "2":
        search_item()
    elif option == "3":
        update_item()
    elif option == "4":
        delete_item()# here i use a simple if and else to let you choose any option
    elif option == "5":
        inventory_total()
    elif option == "6":
        list_inventory()
    elif option == "7":
        break
    else:
        print("¡Error!, no escogiste un valor válido.")

# alr i'm Jeronimo Cardenas and this was all my code i hope you enjoy it.
print("-")
print("_______________")
print("Fin del sistema")